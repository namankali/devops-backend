require("dotenv").config()
const db = require("./db")

const table = "clusters"


const insert_cluster_data = async (data: any) => {
    let data_for_insertion = {
        user_id: data.user_id,
        name: data.name,
        display_name: data.display_name,
        provider: data.provider,
        environment: data.environment,
        kubernetes_version: data?.kubernetes_version || "",
        status: data.status,
        api_server: data.api_server
    }
    console.log("cluster data for insertion", data_for_insertion)
    const result = await db(table).insert(data_for_insertion).returning(["id"])
    return result
}

const fetch_credential = async (user_id: number) => {
    try {
        let query = db.raw(`
                SELECT
                  cc.kubeconfig,
                  c.id as cluster_id
                from clusters as c
                left join cluster_credentials as cc on cc.cluster_id = c.id 
                where c.user_id = ${user_id}
            `)

        const result = await query
        return result.rows
    } catch (error) {
        throw error
    }
}

const fetch_credential_by_cluster_id = async (cluster_id: number) => {
    try {
        let query = db.raw(`
                SELECT
                  cc.kubeconfig,
                  c.id as cluster_id
                from clusters as c
                left join cluster_credentials as cc on cc.cluster_id = c.id 
                where c.id = ${cluster_id}
            `)

        const result = await query
        return result.rows
    } catch (error) {
        throw error
    }
}

const cluster_id_by_user_id = async (user_id: number, provider: string = "") => {
    try {
        let query = db.select([
            `${table}.id as cluster_id`,
            `${table}.display_name`,
        ]).from(table).where('user_id', user_id)

        if (provider !== "") {
            query = query.andWhere("provider", provider)
        }

        return await query
    } catch (error) {
        throw error
    }
}

const fetch_provider_environment = async (user_id: number): Promise<any> => {
    try {
        const query = db.raw(`
                SELECT
                  id,
                  ARRAY_TO_JSON(ARRAY_AGG(DISTINCT provider)) as providers,
                  JSON_AGG(DISTINCT environment) as environments
                FROM clusters
                where user_id = ?
                GROUP by "id"
            `,
            [user_id]
        )

        const result = await query
        return result.rows
    } catch (error) {
        throw error
    }
}

const fetch_environments = async (user_id: number, provider: string): Promise<any> => {
    try {
        const query = db.raw(`
                SELECT
                  id,
                  JSON_AGG(DISTINCT environment) as environments
                FROM clusters
                where user_id = ?
                and provider = ?
                GROUP by "id"
            `,
            [user_id, provider]
        )

        const result = await query
        return result.rows
    } catch (error) {
        throw error
    }
}

export {
    fetch_credential,
    insert_cluster_data,
    cluster_id_by_user_id,
    fetch_credential_by_cluster_id,
    fetch_provider_environment,
    fetch_environments
}